define(
({
	previousMessage: "Предишни избори",
	nextMessage: "Повече избори"
})
);
