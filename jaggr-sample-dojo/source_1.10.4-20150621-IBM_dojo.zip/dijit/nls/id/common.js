define(
({
	buttonOk: "OK",
	buttonCancel: "Batal",
	buttonSave: "Simpan",
	itemClose: "Tutup"
})
);

