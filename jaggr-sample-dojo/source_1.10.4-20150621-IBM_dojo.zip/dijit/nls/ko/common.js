define(
({
	buttonOk: "확인",
	buttonCancel: "취소",
	buttonSave: "저장",
	itemClose: "닫기"
})
);
