define(
({
	loadingState: "A carregar...",
	errorState: "Lamentamos, mas ocorreu um erro"
})
);
