define(
({
		previousMessage: "Poprzednie wybory",
		nextMessage: "Więcej wyborów"
})
);
